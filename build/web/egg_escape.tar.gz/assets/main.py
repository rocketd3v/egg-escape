
import pygame
pygame.init()

from settings import *
from scenes.menu import *
from scenes.credits import *

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("egg escape")

menu_screen = menu()
credits_screen = credits()

run = True
current_scene = "menu"
menu_option = None

while run:
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                current_scene = "menu"
                menu_option = None

        if current_scene == "menu":
            menu_option = menu_screen.menu_selection(event)

    if current_scene == "menu":
        if menu_option == 0:  # play
            current_scene = "game"
            menu_option = None

        elif menu_option == 1:  # help
            pass

        elif menu_option == 2:  # credits
            current_scene = "credits"
            menu_option = None

        elif menu_option == 3:  # end game
            run = False

        screen.fill(white)
        menu_screen.draw_menu(screen)

    elif current_scene == "credits":
        screen.fill(white)
        credits_screen.draw_credits(screen)

    elif current_scene == "game":
        screen.fill(yellow)

    pygame.display.flip()

pygame.quit()
